console.log(new Date());

const purgeS = `
    evils = document.getElementsByTagName("ytd-clarification-renderer");
    if (evils.length > 0) {
      for (i = 0; i < evils.length; ++i)
        evils[i].remove();
    }
    evils = document.getElementsByTagName("ytd-info-panel-container-renderer");
    if (evils.length > 0) {
      for (i = 0; i < evils.length; ++i)
        evils[i].remove();
    }
    delete evils;`

const purgeV = `
    evil = document.getElementById("clarify-box");
    if (evil !== null)
      evil.parentNode.removeChild(evil);
    delete evil;`

//purge = function(id, _) { browser.tabs.executeScript(id, {code:_}); }

/*protect = function(wpn, mark) {
  guardian = new MutationObserver(function(_=guardian) {
    wpn();
    _.disconnect();
  });
  guardian.observe(mark, {childList: true});
}*/

/* browser.tabs.onUpdated.addListener(function(id, change) {
  console.log("SEARCH");
  if (change.url)
    purgeS(id);
}, {urls:["*://*.youtube.com/results?*"]}); */

browser.tabs.onUpdated.addListener(function(id, change) {
  if (change.status == "complete") {
    browser.tabs.executeScript(id, {code:`
      guardian = new MutationObserver(function(_=guardian) {
        eval($(purgeS));
        _.disconnect();
        delete _;
      });
      guardian.observe(document.getElementById('content'), {childList: true});
      `+purgeS});
    console.log("SEARCH");
  }
}, {urls:["*://*.youtube.com/results?*"], properties:["status"]});

/* browser.tabs.onUpdated.addListener(function(id, change) {
  console.log("VIDEO");
  if (change.url)
    purgeV(id);
}, {urls:["*://*.youtube.com/watch?*"]}); */

browser.tabs.onUpdated.addListener(function(id, change) {
  if (change.status == "complete") {
    browser.tabs.executeScript(id, {code:`
      guardian = new MutationObserver(function(_=guardian) {
        eval($(purgeV));
        _.disconnect();
        delete _;
      });
      guardian.observe(document.getElementById('primary-inner'), {childList: true});
      `+purgeV});
    console.log("VIDEO");
  }
}, {urls:["*://*.youtube.com/watch?*"], properties:["status"]});